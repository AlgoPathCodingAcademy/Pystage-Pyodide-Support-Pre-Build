from .sprite import CoreSprite
from .stage import CoreStage

sprite_class = CoreSprite
stage_class = CoreStage
